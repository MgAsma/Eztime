import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-timesheet',
  templateUrl: './my-timesheet.component.html',
  styleUrls: ['./my-timesheet.component.scss']
})
export class MyTimesheetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
